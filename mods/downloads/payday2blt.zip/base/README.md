# Payday 2 SuperBLT
An open source Lua hook for Payday 2, designed and created for ease of use for both players and modders.  
This repository is for the Lua base that controls and loads mods into Payday 2, and the options and save files associated with the BLT. The DLL hook code can be found in it's own [repository](https://gitlab.com/znixian/payday2-superblt).

This is the developer repository, and should only be used if you know what you're doing. If you don't, visit https://superblt.znix.xyz/ to get information regarding the installation of SuperBLT.

## Download
Visit https://superblt.znix.xyz/ to get the latest stable download.  
